/* RGB color sequence is :  RRRRRGGGGGGBBBBB
  Color data : 16 bits 
 original bmp size : 80 x 60 ; bit per pixel : 4 
  Bits Interface : 8  */
unsigned char code 3[]={
};